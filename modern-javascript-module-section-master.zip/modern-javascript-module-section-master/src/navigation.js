export default function () {
  return '<div>Logo</div>';
}

export function multiply(numOne, numTwo) {
  return numOne * numTwo;
}

export const greeting = 'Hi there';