import navigation, { greeting, multiply } from './navigation';

console.log(greeting);